# Probeprüfung FS22

Instruktion: 

* Starten Sie Jupyter Lab wie gewohnt
* Öffnen Sie dann unter "notebooks/Probepruefung" das Notebook "Probepruefung_FS22.ipynb"
* Lösen Sie die Aufgaben durch ergänzung mit Quelltext an den entsprechenden Orten
* **Speichern** Sie ihr Notebook
* Laden Sie das gespeicherte Notebook auf ihren Computer
* Geben Sie das heruntergeladene Notebook über ILIAS ab
* Nach der Abgabe erhalten Sie eine Musterlösung via ILIAS, die sie in Jupyter Lab hochladen und anschauen können
