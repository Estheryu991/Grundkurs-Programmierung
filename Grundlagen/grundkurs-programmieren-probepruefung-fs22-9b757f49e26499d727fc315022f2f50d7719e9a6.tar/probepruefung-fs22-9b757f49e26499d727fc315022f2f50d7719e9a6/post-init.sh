#!/bin/bash

mkdir -p /home/jovyan/work/.jupyter_config/lab/user-settings/@jupyterlab/toc-extension
cp ./.user-settings/@jupyterlab/toc-extension/plugin.jupyterlab-settings /home/jovyan/work/.jupyter_config/lab/user-settings/@jupyterlab/toc-extension/plugin.jupyterlab-settings